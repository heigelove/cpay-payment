#!/bin/bash

# 配置变量
REMOTE_USER="ubuntu"                  # 远程服务器的用户名
USERNAME="root"
PASSWORD="Folli123!" 
REMOTE_DIR="/www/wwwroot/go/api/api"              # 远程服务器上的部署目录
LOCAL_DIR="/root/deploy/xlianghua/arbitrage/app/api/api"                  # 本地应用程序目录
DEPLOY_SCRIPT="./deploy_api.sh"           # 本地部署脚本（可选）
COMMAND="sh /home/ubuntu/deploy_api.sh"
ARG1="$1"

cd /root/deploy/xlianghua
git pull
cd /root/deploy/xlianghua/arbitrage/app/api
/usr/local/go/bin/go build api.go
cd /root/deploy

# 定义函数：处理每一行数据
process_line() {
	local REMOTE_HOST=$1
	local PRIVATE_KEY=$2
	local DOMAIN=$3
	
	echo "REMOTE_HOST: $REMOTE_HOST, PRIVATE_KEY: $PRIVATE_KEY, DOMAIN: $DOMAIN"
	
	# 检查私钥文件是否存在
    if [[ ! -f "$PRIVATE_KEY" ]]; then
      echo "错误：私钥文件 $PRIVATE_KEY 不存在！"
      return
    fi

	# ssh 通过私钥登录到服务器
	#ssh -i "$PRIVATE_KEY" "$REMOTE_USER@$REMOTE_HOST"

	scp -o ConnectTimeout=5 -o StrictHostKeyChecking=no -i "$PRIVATE_KEY" "$LOCAL_DIR" "$REMOTE_USER@$REMOTE_HOST:/home/ubuntu/api"
    
    if [[ $ARG1 != "" ]]; then 
        scp -o ConnectTimeout=5 -o StrictHostKeyChecking=no -i "$PRIVATE_KEY" "$DEPLOY_SCRIPT" "$REMOTE_USER@$REMOTE_HOST:/home/ubuntu/deploy_api.sh"
    fi

	# 通过 su 切换到 root 并执行命令
	sshpass -p "$PASSWORD" ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no -i "$PRIVATE_KEY" -t "$REMOTE_USER@$REMOTE_HOST" "sudo -i bash -c '$COMMAND'"
	
	echo "-----------------------------------------------------"
}


while IFS=, read -r ip pk ym <&3
do
	if [[ "$ip" != "ip" ]]; then
		if [[ "$1" == "" ]]; then 
		    process_line "$ip" "$pk" "$ym"
		elif [[ "$1" == "$ip" ]]; then
		    process_line "$ip" "$pk" "$ym"
		fi
		
	fi
	
done 3< /root/deploy/key/server.csv

