#!/bin/bash
unzip -qo /home/ubuntu/dist.zip -d /www/wwwroot/admin
sed -i 's|http://127.0.0.1:8080|https://6045tg.xlianghua.com|g' /www/wwwroot/admin/*.js
sed -i 's|http://127.0.0.1:8080|https://6045tg.xlianghua.com|g' /www/wwwroot/admin/static/js/*.js
