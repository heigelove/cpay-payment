
UPDATE cd_robots SET environment=REPLACE(environment,"}]]",'}]') WHERE id=1;