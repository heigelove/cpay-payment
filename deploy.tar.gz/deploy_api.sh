#!/bin/bash
cp -f /home/ubuntu/api /www/wwwroot/go/api/api
chmod 755 /www/wwwroot/go/api/api
sed -i 's/Mode: test/Mode: release/g' /www/wwwroot/go/api/etc/config.yaml
# /www/server/panel/pyenv/bin/python /www/server/panel/pyenv/bin/supervisorctl stop api:api_00
/www/server/panel/pyenv/bin/python /www/server/panel/pyenv/bin/supervisorctl restart api:api_00

