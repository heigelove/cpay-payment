#!/bin/bash

# 配置变量
REMOTE_USER="ubuntu"                  # 远程服务器的用户名
USERNAME="root"
PASSWORD="Folli123!" 
REMOTE_DIR="/www/wwwroot/admin"              # 远程服务器上的部署目录
LOCAL_DIR="./dist.zip"                  # 本地应用程序目录
DEPLOY_SCRIPT="./deploy_dist.sh"           # 本地部署脚本（可选）
COMMAND="sh /home/ubuntu/deploy_dist.sh"

# 定义函数：处理每一行数据
process_line() {
	local REMOTE_HOST=$1
	local PRIVATE_KEY=$2
	local DOMAIN=$3
	
	echo "REMOTE_HOST: $REMOTE_HOST, PRIVATE_KEY: $PRIVATE_KEY, DOMAIN: $DOMAIN"
	
	# 检查私钥文件是否存在
    if [[ ! -f "$PRIVATE_KEY" ]]; then
      echo "错误：私钥文件 $PRIVATE_KEY 不存在！"
      return
    fi
    
    echo "#!/bin/bash" > $DEPLOY_SCRIPT
    # echo "mkdir /www/wwwroot/test" >> $DEPLOY_SCRIPT
    echo "unzip -qo /home/ubuntu/dist.zip -d /www/wwwroot/admin" >> $DEPLOY_SCRIPT
    echo "sed -i 's|http://127.0.0.1:8080|https://$DOMAIN|g' /www/wwwroot/admin/*.js" >> $DEPLOY_SCRIPT
    echo "sed -i 's|http://127.0.0.1:8080|https://$DOMAIN|g' /www/wwwroot/admin/static/js/*.js" >> $DEPLOY_SCRIPT
    # echo "sed -i 's/127.0.0.1/$DOMAIN/g' /www/wwwroot/admin/*.js" >> $DEPLOY_SCRIPT
    # echo "sed -i 's/127.0.0.1/$DOMAIN/g' /www/wwwroot/admin/static/js/*.js" >> $DEPLOY_SCRIPT
    # echo "sed -i 's/http:/https:/g' /www/wwwroot/admin/*.js" >> $DEPLOY_SCRIPT
    # echo "sed -i 's/http:/https:/g' /www/wwwroot/admin/static/js/*.js" >> $DEPLOY_SCRIPT
    
    # cat $DEPLOY_SCRIPT


	# ssh 通过私钥登录到服务器
	#ssh -i "$PRIVATE_KEY" "$REMOTE_USER@$REMOTE_HOST"

	scp -o ConnectTimeout=5 -o StrictHostKeyChecking=no -i "$PRIVATE_KEY" "$LOCAL_DIR" "$REMOTE_USER@$REMOTE_HOST:/home/ubuntu/dist.zip"
	
	scp -o ConnectTimeout=5 -o StrictHostKeyChecking=no -i "$PRIVATE_KEY" "$DEPLOY_SCRIPT" "$REMOTE_USER@$REMOTE_HOST:/home/ubuntu/deploy_dist.sh"

	# 通过 su 切换到 root 并执行命令
	sshpass -p "$PASSWORD" ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no -i "$PRIVATE_KEY" -t "$REMOTE_USER@$REMOTE_HOST" "sudo -i bash -c '$COMMAND'"
	
	echo "-----------------------------------------------------"
}


while IFS=, read -r ip pk ym <&3
do
	if [[ "$ip" != "ip" ]]; then
		if [[ "$1" == "" ]]; then 
		    process_line "$ip" "$pk" "$ym"
		elif [[ "$1" == "$ip" ]]; then
		    process_line "$ip" "$pk" "$ym"
		fi
	fi
done 3< /root/deploy/key/server.csv

