#!/bin/bash

# CSV 文件路径
csv_file="/root/deploy/key/server.csv"

# 最大并发数
max_jobs=3

# 任务函数：通过 SSH 连接到远程主机并执行命令
task() {
    local host="$1"
    local key="$2"
    local command="ls"

    echo "正在连接到 $host..."
    ssh -i "$key" "ubuntu@$host" "$command"
    if [[ $? -eq 0 ]]; then
        echo "成功: $host 执行命令 '$command'"
    else
        echo "失败: $host 执行命令 '$command'"
    fi
}

# 创建一个文件描述符（&3）用于控制并发
exec 3>&1  # 将文件描述符 3 重定向到标准输出

# 读取 CSV 文件（跳过标题行）
tail -n +2 "$csv_file" | while IFS=, read -r host key; do
    # 启动任务
    {
        task "$host" "$key"
    } &

    # 控制并发数
    if [[ $(jobs -r -p | wc -l) -ge $max_jobs ]]; then
        read -u 3 -t 1  # 从文件描述符 3 读取，等待一个任务完成
    fi
done 3>&-  # 关闭文件描述符 3

# 等待剩余任务完成
wait

echo "所有任务完成"