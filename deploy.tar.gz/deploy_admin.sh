#!/bin/bash
cp -f /home/ubuntu/admin /www/wwwroot/go/admin/admin
chmod 755 /www/wwwroot/go/admin/admin
/www/server/panel/pyenv/bin/python /www/server/panel/pyenv/bin/supervisorctl restart admin:admin_00

